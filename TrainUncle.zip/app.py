import logging
import requests
import regex
import lxml.html as lh


from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.utils import is_request_type, is_intent_name
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model.ui import SimpleCard
from ask_sdk_model import Response

sb = SkillBuilder()

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)




class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ( is_request_type("LaunchRequest")(handler_input) or is_intent_name("welcome")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speech_text = "Welcome to Train Uncle, you can say where is One Four One One Four"

        handler_input.response_builder.speak(speech_text).set_card(
            SimpleCard("Train Uncle", speech_text)).set_should_end_session(
            False)
        return handler_input.response_builder.response


class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("getStatus")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        # speech_text = "Hello Python World from Classes!"
        trainNumber = str(handler_input.request_envelope.request.intent.slots["val"].value)

        if(len(trainNumber)==5):

            slotday = handler_input.request_envelope.request.intent.slots["day"].value
            if (str(slotday) == "None"):
                url = "https://www.spoturtrain.info/newspoturtrain.php?train_num="+str(trainNumber)+"&spotday=today&submit=Submit"
            else:
                url = "https://www.spoturtrain.info/newspoturtrain.php?train_num="+str(trainNumber)+"&spotday="+str(slotday)+"&submit=Submit"
            
            #speech_text = trainNumber
            page = requests.get(url)
            doc = lh.fromstring(page.content)


            try:
                k = doc.xpath("/html/body/div[2]/div/div[1]/div/div[2]/center/div")
                text = lh.tostring(k[0]).decode("utf-8")
                nt = regex.sub('<[^>]+>','',text)
                nt = regex.sub('\([^)]*\)','',nt)
                nt = nt.split("Train")
                nt = "The Running Status of "+trainNumber+". Train "+nt[1]
                speech_text =nt 
            except:
                k = doc.xpath("/html/body/div[2]/div/div[1]/div/div[2]/center/h4")
                text = lh.tostring(k[0]).decode("utf-8")
                nt = regex.sub('<[^>]+>','',text)
                nt = regex.sub('\([^)]*\)','',nt)
                nt = nt.split("Or")
                nt = nt[0] + "And Try Again !!"
                speech_text =nt
            speech_text = speech_text.replace("IST","")
            if "doesn't run on Given Date." in speech_text:
                speech_text = "Train Number "+trainNumber+" doesn't run on Given Date."
            if "FULLY CANCELLED" in speech_text:
                speech_text = "Train Number "+trainNumber+" is FULLY CANCELLED."
            
            handler_input.response_builder.speak(speech_text).set_card(
                SimpleCard("Train Uncle", speech_text)).set_should_end_session(
                True)
            return handler_input.response_builder.response

        else:
            speech_text = "Please Enter Correct Train Number !!!"
            handler_input.response_builder.speak(speech_text).set_card(
                SimpleCard("Train Uncle", speech_text))
            return handler_input.response_builder.response

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speech_text = "You can say ask Train Uncle Where is followed by train number"

        handler_input.response_builder.speak(speech_text).ask(
            speech_text).set_card(SimpleCard(
                "Train Uncle", speech_text))
        return handler_input.response_builder.response


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (is_intent_name("AMAZON.CancelIntent")(handler_input) or
                is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speech_text = "Goodbye!"

        handler_input.response_builder.speak(speech_text).set_card(
            SimpleCard("Train Uncle", speech_text))
        return handler_input.response_builder.response


class FallbackIntentHandler(AbstractRequestHandler):
    """AMAZON.FallbackIntent is available in these locales.
    This handler will not be triggered except in supported locales,
    so it is safe to deploy on any locale.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speech_text = "Sorry I am unable to understand that. "
        reprompt = "You can say where is followed by train number!!"
        handler_input.response_builder.speak(speech_text).ask(reprompt)
        return handler_input.response_builder.response


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        return handler_input.response_builder.response


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Catch all exception handler, log exception and
    respond with custom message.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speech = "Sorry, there was some problem. Please try again!!"
        handler_input.response_builder.speak(speech).ask(speech)

        return handler_input.response_builder.response


sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())

sb.add_exception_handler(CatchAllExceptionHandler())

handler = sb.lambda_handler()
